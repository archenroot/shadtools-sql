package com.shadworld.sql.tablemeta;

public class TestCreate
{
  public static void main(String[] args)
  {
  }
}

/* Location:           D:\development\cryptocurrency\crypto-pool-poolserverj\poolserverj-main\etc\lib\lib_non-maven\shadtools-sql-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.shadworld.sql.tablemeta.TestCreate
 * JD-Core Version:    0.6.2
 */