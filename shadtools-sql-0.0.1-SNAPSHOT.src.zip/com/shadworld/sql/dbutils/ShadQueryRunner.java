package com.shadworld.sql.dbutils;

import org.apache.commons.dbutils.QueryRunner;

public class ShadQueryRunner extends QueryRunner
{
}

/* Location:           D:\development\cryptocurrency\crypto-pool-poolserverj\poolserverj-main\etc\lib\lib_non-maven\shadtools-sql-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.shadworld.sql.dbutils.ShadQueryRunner
 * JD-Core Version:    0.6.2
 */